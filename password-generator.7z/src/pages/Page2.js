import React from 'react';
import './Page2.css'; // CSS dosyasını import et

const Page2 = () => (
    <div className="container">
        <h1>Sayfa 2</h1>
        <p>Düzenlenecek.</p>
    </div>
);

export default Page2;
