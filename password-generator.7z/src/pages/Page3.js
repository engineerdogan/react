import React from 'react';
import './Page3.css'; // CSS dosyasını import et

const Page3 = () => (
    <div className="container">
        <h1>Sayfa 3</h1>
        <p>Düzenlenecek.</p>
    </div>
);

export default Page3;
