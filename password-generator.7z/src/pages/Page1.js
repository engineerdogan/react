import React from 'react';
import './Page1.css'; // CSS dosyasını import et

const Page1 = () => (
    <div className="container">
        <h1>Sayfa 1</h1>
        <p>Düzenlenecek.</p>
    </div>
);

export default Page1;
